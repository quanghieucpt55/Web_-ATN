const LogoutLayout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default LogoutLayout;
