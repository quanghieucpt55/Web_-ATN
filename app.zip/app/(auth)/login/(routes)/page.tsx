import LoginForm from "./components/login-form";

const LoginPage = () => {
  return (
    <section
      className="w-full h-screen flex items-center justify-center"
      style={{
        backgroundImage: "url('leaflet/images/background.jpg')",
        backgroundSize: "cover", // Ảnh phủ toàn bộ màn hình
        backgroundPosition: "center", // Căn giữa ảnh nền
        backgroundRepeat: "no-repeat", // Không lặp lại ảnh
      }}
    >
      <LoginForm />
    </section>
  );
};

export default LoginPage;
